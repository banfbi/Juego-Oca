<?php
    $tirada = rand(1, 6);
    echo json_encode(['tirada' => $tirada]);
?>
